var playerimage,player,enemy1image,enemy1,enemy2image,enemy2;
var enemy3image,enemy3,enemy4image,enemy4,axeimage,axe,backgroundimage;

var wall1,wall2

function preload(){
  playerimage=loadImage("images/player.png")
 enemy1image=loadImage("images/enemy1.png")
 enemy2image=loadImage("images/enemy2.png")
 enemy3image=loadImage("images/enemy3.png")
 enemy4image=loadImage("images/enemy4.png")
 axeimage=loadAnimation("images/1.png","images/2.png","images/3.png","images/4.png","images/5.png","images/6.png")
 backgroundimage=loadImage("images/background.jpg")
}
function setup() {
  createCanvas(displayWidth,400);
  player=createSprite(235,253)
  player.addImage(playerimage)
 player.scale=0.6

 enemy1=createSprite(488,244)
 enemy1.addImage(enemy1image)
 enemy1.velocityY = 6


 enemy2=createSprite(706,249)
 enemy2.addImage(enemy2image)
 enemy2.scale=0.6
 enemy2.velocityY = -6

 enemy3=createSprite(963,249)
 enemy3.addImage(enemy3image)
 enemy3.velocityY = 6

 enemy4=createSprite(1167,249)
 enemy4.addImage(enemy4image)
 enemy4.scale=0.6
 enemy4.velocityY = -6

 wall1 = createSprite(displayWidth/2,390,displayWidth,20)
 wall1.visible = false

 wall2 = createSprite(displayWidth/2,0,displayWidth,20)
 wall2.visible = false
}

function draw() {
  background(backgroundimage); 
  fill("white")
  textSize(35)
  //text(mouseX+","+mouseY,mouseX,mouseY) 
  enemy1.bounceOff(wall1)
  enemy1.bounceOff(wall2)
  drawSprites();
}